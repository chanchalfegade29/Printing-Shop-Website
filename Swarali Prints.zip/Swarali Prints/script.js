// ===== DOM Elements =====
const header = document.getElementById('header');
const navMenu = document.getElementById('nav-menu');
const navToggle = document.getElementById('nav-toggle');
const navClose = document.getElementById('nav-close');
const navLinks = document.querySelectorAll('.nav-link');
const uploadArea = document.getElementById('uploadArea');
const fileUpload = document.getElementById('fileUpload');
const fileName = document.getElementById('fileName');
const uploadForm = document.getElementById('uploadForm');
const successModal = document.getElementById('successModal');
const filterBtns = document.querySelectorAll('.filter-btn');
const galleryItems = document.querySelectorAll('.gallery-item');

// ===== Mobile Menu Toggle =====
if (navToggle) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });
}

if (navClose) {
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('active');
        document.body.style.overflow = '';
    });
}

// Close menu when clicking on nav links
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        document.body.style.overflow = '';
    });
});

// ===== Header Scroll Effect =====
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
});

// ===== Interactive Hero Elements =====

// Mouse Following Glow
const hero = document.querySelector('.hero');
const mouseGlow = document.getElementById('mouseGlow');

if (hero && mouseGlow) {
    hero.addEventListener('mousemove', (e) => {
        const rect = hero.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        mouseGlow.style.left = x + 'px';
        mouseGlow.style.top = y + 'px';
    });
}

// Typing Effect
const typingText = document.getElementById('typingText');
const words = ['printing solutions', 'photo prints', 'business cards', 'wedding invitations', 'custom banners', 'laminated documents'];
let wordIndex = 0;
let charIndex = 0;
let isDeleting = false;

function typeEffect() {
    if (!typingText) return;
    
    const currentWord = words[wordIndex];
    
    if (isDeleting) {
        typingText.textContent = currentWord.substring(0, charIndex - 1);
        charIndex--;
    } else {
        typingText.textContent = currentWord.substring(0, charIndex + 1);
        charIndex++;
    }
    
    let typeSpeed = isDeleting ? 50 : 100;
    
    if (!isDeleting && charIndex === currentWord.length) {
        typeSpeed = 2000; // Pause at end
        isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        wordIndex = (wordIndex + 1) % words.length;
        typeSpeed = 500; // Pause before new word
    }
    
    setTimeout(typeEffect, typeSpeed);
}

// Start typing effect
if (typingText) {
    setTimeout(typeEffect, 1000);
}

// Create Particles
const particlesContainer = document.getElementById('particles');

function createParticles() {
    if (!particlesContainer) return;
    
    for (let i = 0; i < 30; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 8 + 's';
        particle.style.animationDuration = (Math.random() * 5 + 6) + 's';
        particlesContainer.appendChild(particle);
    }
}

createParticles();

// ===== Floating Orbs =====
const floatingOrbs = document.getElementById('floatingOrbs');

function createOrbs() {
    if (!floatingOrbs) return;
    
    const colors = [
        'rgba(0, 212, 255, 0.4)',
        'rgba(0, 153, 255, 0.4)',
        'rgba(123, 45, 142, 0.4)',
        'rgba(233, 30, 140, 0.4)',
        'rgba(255, 193, 7, 0.3)'
    ];
    
    for (let i = 0; i < 8; i++) {
        const orb = document.createElement('div');
        orb.className = 'orb';
        const size = Math.random() * 80 + 40;
        orb.style.width = size + 'px';
        orb.style.height = size + 'px';
        orb.style.left = Math.random() * 100 + '%';
        orb.style.top = Math.random() * 100 + '%';
        orb.style.background = colors[Math.floor(Math.random() * colors.length)];
        orb.style.animationDelay = Math.random() * 5 + 's';
        orb.style.animationDuration = (Math.random() * 5 + 8) + 's';
        floatingOrbs.appendChild(orb);
    }
}

createOrbs();

// ===== Sparkles =====
const sparklesContainer = document.getElementById('sparkles');

function createSparkles() {
    if (!sparklesContainer) return;
    
    for (let i = 0; i < 20; i++) {
        const sparkle = document.createElement('div');
        sparkle.className = 'sparkle';
        sparkle.style.left = Math.random() * 100 + '%';
        sparkle.style.top = Math.random() * 100 + '%';
        sparkle.style.animationDelay = Math.random() * 3 + 's';
        sparkle.style.animationDuration = (Math.random() * 1.5 + 1.5) + 's';
        sparklesContainer.appendChild(sparkle);
    }
}

createSparkles();

// ===== Click Ripple Effect =====
const rippleContainer = document.getElementById('rippleContainer');
const heroSection = document.querySelector('.hero');

if (heroSection && rippleContainer) {
    heroSection.addEventListener('click', (e) => {
        const rect = heroSection.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const ripple = document.createElement('div');
        ripple.className = 'ripple';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        rippleContainer.appendChild(ripple);
        
        // Remove ripple after animation
        setTimeout(() => ripple.remove(), 1000);
    });
}

// ===== Cursor Trail Effect =====
const cursorTrail = document.getElementById('cursorTrail');
let lastTrailTime = 0;

if (heroSection && cursorTrail) {
    heroSection.addEventListener('mousemove', (e) => {
        const now = Date.now();
        if (now - lastTrailTime < 30) return; // Throttle
        lastTrailTime = now;
        
        const rect = heroSection.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const trail = document.createElement('div');
        trail.className = 'trail-dot';
        trail.style.left = x + 'px';
        trail.style.top = y + 'px';
        
        // Random colors for trail
        const colors = [
            'rgba(0, 212, 255, 0.8)',
            'rgba(233, 30, 140, 0.8)',
            'rgba(255, 193, 7, 0.8)',
            'rgba(123, 45, 142, 0.8)'
        ];
        trail.style.background = `radial-gradient(circle, ${colors[Math.floor(Math.random() * colors.length)]}, transparent)`;
        
        cursorTrail.appendChild(trail);
        
        // Remove trail after animation
        setTimeout(() => trail.remove(), 800);
    });
}

// ===== Parallax Effect on Mouse Move =====
const floatingElements = document.querySelector('.floating-elements');
const floatingShapes = document.querySelector('.floating-shapes');
const animatedRings = document.querySelector('.animated-rings');

if (heroSection) {
    heroSection.addEventListener('mousemove', (e) => {
        const rect = heroSection.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) / 30;
        const y = (e.clientY - rect.top - rect.height / 2) / 30;
        
        if (floatingElements) {
            floatingElements.style.transform = `translate(${x * 1.5}px, ${y * 1.5}px)`;
        }
        if (floatingShapes) {
            floatingShapes.style.transform = `translate(${-x}px, ${-y}px)`;
        }
        if (animatedRings) {
            animatedRings.style.transform = `translate(calc(-50% + ${x * 0.5}px), calc(-50% + ${y * 0.5}px))`;
        }
    });
    
    heroSection.addEventListener('mouseleave', () => {
        if (floatingElements) floatingElements.style.transform = '';
        if (floatingShapes) floatingShapes.style.transform = '';
        if (animatedRings) animatedRings.style.transform = 'translate(-50%, -50%)';
    });
}

// ===== Floating Icons Random Movement =====
const floatItems = document.querySelectorAll('.float-item');

floatItems.forEach((item, index) => {
    // Add random movement path
    setInterval(() => {
        const randomX = (Math.random() - 0.5) * 20;
        const randomY = (Math.random() - 0.5) * 20;
        const randomRotate = (Math.random() - 0.5) * 30;
        item.style.transform = `translate(${randomX}px, ${randomY}px) rotate(${randomRotate}deg)`;
    }, 2000 + index * 500);
});

// Duplicate showcase cards for infinite scroll
const showcaseTrack = document.getElementById('showcaseTrack');
if (showcaseTrack) {
    const cards = showcaseTrack.innerHTML;
    showcaseTrack.innerHTML += cards; // Duplicate for seamless loop
}

// Stats Counter Animation
const statNumbers = document.querySelectorAll('.stat-number');

function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-target'));
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    
    const updateCounter = () => {
        current += step;
        if (current < target) {
            element.textContent = Math.floor(current).toLocaleString();
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target.toLocaleString();
        }
    };
    
    updateCounter();
}

// Intersection Observer for Stats
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const statNumbers = entry.target.querySelectorAll('.stat-number');
            statNumbers.forEach(stat => animateCounter(stat));
            statsObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

const heroStats = document.querySelector('.hero-stats');
if (heroStats) {
    statsObserver.observe(heroStats);
}

// ===== Active Navigation Link =====
const sections = document.querySelectorAll('section[id]');

function scrollActive() {
    const scrollY = window.pageYOffset;
    
    sections.forEach(current => {
        const sectionHeight = current.offsetHeight;
        const sectionTop = current.offsetTop - 150;
        const sectionId = current.getAttribute('id');
        const navLink = document.querySelector('.nav-link[href*=' + sectionId + ']');
        
        if (navLink) {
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                navLink.classList.add('active');
            } else {
                navLink.classList.remove('active');
            }
        }
    });
}

window.addEventListener('scroll', scrollActive);

// ===== Upload Section Particles =====
const uploadParticles = document.getElementById('uploadParticles');

function createUploadParticles() {
    if (!uploadParticles) return;
    
    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.className = 'upload-particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 12 + 's';
        particle.style.animationDuration = (Math.random() * 8 + 8) + 's';
        uploadParticles.appendChild(particle);
    }
}

createUploadParticles();

// ===== Quantity Buttons =====
const qtyMinus = document.getElementById('qtyMinus');
const qtyPlus = document.getElementById('qtyPlus');
const quantityInput = document.getElementById('quantity');

if (qtyMinus && qtyPlus && quantityInput) {
    qtyMinus.addEventListener('click', () => {
        let value = parseInt(quantityInput.value) || 1;
        if (value > 1) {
            quantityInput.value = value - 1;
            quantityInput.dispatchEvent(new Event('change'));
        }
    });
    
    qtyPlus.addEventListener('click', () => {
        let value = parseInt(quantityInput.value) || 1;
        quantityInput.value = value + 1;
        quantityInput.dispatchEvent(new Event('change'));
    });
}

// ===== Upload Steps Progress =====
const uploadSteps = document.querySelectorAll('.step');
const stepLines = document.querySelectorAll('.step-line');

function updateUploadSteps(stepNumber) {
    uploadSteps.forEach((step, index) => {
        if (index < stepNumber) {
            step.classList.add('active', 'completed');
        } else if (index === stepNumber) {
            step.classList.add('active');
            step.classList.remove('completed');
        } else {
            step.classList.remove('active', 'completed');
        }
    });
    
    stepLines.forEach((line, index) => {
        if (index < stepNumber) {
            line.classList.add('active');
        } else {
            line.classList.remove('active');
        }
    });
}

// Track form progress
const formInputs = document.querySelectorAll('#uploadForm input, #uploadForm select, #uploadForm textarea');
formInputs.forEach(input => {
    input.addEventListener('change', () => {
        checkFormProgress();
    });
    input.addEventListener('input', () => {
        checkFormProgress();
    });
});

function checkFormProgress() {
    const hasFile = fileName && fileName.textContent.length > 0;
    const printType = document.getElementById('printType');
    const paperSize = document.getElementById('paperSize');
    const customerName = document.getElementById('customerName');
    const customerPhone = document.getElementById('customerPhone');
    
    const hasConfig = printType && printType.value && paperSize && paperSize.value;
    const hasContact = customerName && customerName.value && customerPhone && customerPhone.value;
    
    if (hasFile && hasConfig && hasContact) {
        updateUploadSteps(2);
    } else if (hasFile) {
        updateUploadSteps(1);
    } else {
        updateUploadSteps(0);
    }
}

// ===== File Upload with Progress Animation =====
if (uploadArea) {
    // Click to upload
    uploadArea.addEventListener('click', () => {
        fileUpload.click();
    });
    
    // Drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });
    
    // File input change
    fileUpload.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });
}

function handleFile(file) {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    const maxSize = 10 * 1024 * 1024; // 10MB
    
    if (!allowedTypes.includes(file.type)) {
        alert('Please upload a PDF, JPG, or PNG file.');
        return;
    }
    
    if (file.size > maxSize) {
        alert('File size should not exceed 10MB.');
        return;
    }
    
    // Simulate upload progress
    simulateUploadProgress(file);
}

function simulateUploadProgress(file) {
    const progressBar = document.querySelector('.progress-bar');
    const progressPercent = document.getElementById('progressPercent');
    
    uploadArea.classList.add('uploading');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            
            setTimeout(() => {
                uploadArea.classList.remove('uploading');
                fileName.textContent = '📎 ' + file.name;
                fileName.style.display = 'block';
                updateUploadSteps(1);
                
                // Add success animation
                uploadArea.classList.add('upload-success');
                setTimeout(() => {
                    uploadArea.classList.remove('upload-success');
                }, 1000);
            }, 300);
        }
        
        if (progressBar) progressBar.style.width = progress + '%';
        if (progressPercent) progressPercent.textContent = Math.floor(progress);
    }, 100);
}

// ===== Form Input Animations =====
const allFormInputs = document.querySelectorAll('#uploadForm input, #uploadForm select, #uploadForm textarea');
allFormInputs.forEach(input => {
    input.addEventListener('focus', () => {
        input.parentElement.classList.add('focused');
    });
    
    input.addEventListener('blur', () => {
        input.parentElement.classList.remove('focused');
    });
});

// ===== Form Submission =====
if (uploadForm) {
    uploadForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Validate form
        const customerName = document.getElementById('customerName').value;
        const customerPhone = document.getElementById('customerPhone').value;
        const printType = document.getElementById('printType').value;
        const paperSize = document.getElementById('paperSize').value;
        
        if (!customerName || !customerPhone || !printType || !paperSize) {
            alert('Please fill in all required fields.');
            return;
        }
        
        // Validate phone number (basic validation)
        const phoneRegex = /^[0-9]{10}$/;
        if (!phoneRegex.test(customerPhone.replace(/\s/g, ''))) {
            alert('Please enter a valid 10-digit phone number.');
            return;
        }
        
        // Show success modal
        successModal.classList.add('active');
        
        // Reset form
        uploadForm.reset();
        fileName.textContent = '';
        fileName.style.display = 'none';
        
        // Send to WhatsApp (optional - uncomment if needed)
        // sendToWhatsApp();
    });
}

// ===== Close Modal =====
function closeModal() {
    successModal.classList.remove('active');
}

// Close modal on outside click
if (successModal) {
    successModal.addEventListener('click', (e) => {
        if (e.target === successModal) {
            closeModal();
        }
    });
}

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && successModal.classList.contains('active')) {
        closeModal();
    }
});

// ===== Gallery Filter =====
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Remove active class from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        // Add active class to clicked button
        btn.classList.add('active');
        
        const filter = btn.getAttribute('data-filter');
        
        galleryItems.forEach((item, index) => {
            const category = item.getAttribute('data-category');
            
            if (filter === 'all' || filter === category) {
                item.classList.remove('hidden');
                item.style.display = 'block';
                // Staggered animation
                setTimeout(() => {
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0) scale(1)';
                }, 50 + (index * 50));
            } else {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px) scale(0.9)';
                setTimeout(() => {
                    item.style.display = 'none';
                    item.classList.add('hidden');
                }, 300);
            }
        });
    });
});

// ===== Scroll Reveal Animation =====
function scrollReveal() {
    const reveals = document.querySelectorAll('.service-card, .feature-card, .contact-card, .gallery-item, .wedding-card');
    
    reveals.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.classList.add('revealed');
        }
    });
}

window.addEventListener('scroll', scrollReveal);
window.addEventListener('load', scrollReveal);

// ===== Smooth Scroll for Anchor Links =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const headerOffset = 80;
            const elementPosition = target.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
            
            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// ===== Button Ripple Effect =====
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', function(e) {
        const x = e.clientX - e.target.offsetLeft;
        const y = e.clientY - e.target.offsetTop;
        
        const ripple = document.createElement('span');
        ripple.style.left = `${x}px`;
        ripple.style.top = `${y}px`;
        ripple.classList.add('ripple');
        
        this.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
});

// ===== Parallax Effect for Floating Shapes =====
document.addEventListener('mousemove', (e) => {
    const shapes = document.querySelectorAll('.shape');
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    
    shapes.forEach((shape, index) => {
        const speed = (index + 1) * 20;
        const xOffset = (x - 0.5) * speed;
        const yOffset = (y - 0.5) * speed;
        
        shape.style.transform = `translate(${xOffset}px, ${yOffset}px)`;
    });
});

// ===== Intersection Observer for Animations =====
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            
            // Add staggered animation delay for grid items
            const parent = entry.target.parentElement;
            const siblings = parent.querySelectorAll('.service-card, .feature-card');
            
            siblings.forEach((sibling, index) => {
                sibling.style.transitionDelay = `${index * 0.1}s`;
            });
        }
    });
}, observerOptions);

// Observe all animated elements
document.querySelectorAll('.service-card, .feature-card, .gallery-item, .contact-card').forEach(el => {
    el.classList.add('scroll-reveal');
    observer.observe(el);
});

// ===== Counter Animation (if needed) =====
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    function updateCounter() {
        start += increment;
        if (start < target) {
            element.textContent = Math.floor(start);
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target;
        }
    }
    
    updateCounter();
}

// ===== Typing Effect for Tagline =====
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.textContent = '';
    
    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// ===== Gallery Parallax Effect =====
function galleryParallax() {
    const gallerySection = document.querySelector('.gallery');
    const galleryBlobs = document.querySelectorAll('.gallery-blob');
    
    if (gallerySection && galleryBlobs.length > 0) {
        const rect = gallerySection.getBoundingClientRect();
        const scrollProgress = (window.innerHeight - rect.top) / (window.innerHeight + rect.height);
        
        if (scrollProgress > 0 && scrollProgress < 1) {
            galleryBlobs.forEach((blob, index) => {
                const speed = (index + 1) * 20;
                const yOffset = (scrollProgress - 0.5) * speed;
                blob.style.transform = `translateY(${yOffset}px) scale(${1 + scrollProgress * 0.05})`;
            });
        }
    }
}

window.addEventListener('scroll', galleryParallax);

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', () => {
    // Add loaded class to body for initial animations
    document.body.classList.add('loaded');
    
    // Initial scroll position check
    scrollActive();
    scrollReveal();
    galleryParallax();
});

// ===== Send Order to WhatsApp (Optional) =====
function sendToWhatsApp() {
    const customerName = document.getElementById('customerName').value;
    const customerPhone = document.getElementById('customerPhone').value;
    const printType = document.getElementById('printType').value;
    const paperSize = document.getElementById('paperSize').value;
    const quantity = document.getElementById('quantity').value;
    const notes = document.getElementById('notes').value;
    
    const message = `*New Print Order*%0A%0A` +
        `*Name:* ${customerName}%0A` +
        `*Phone:* ${customerPhone}%0A` +
        `*Print Type:* ${printType}%0A` +
        `*Paper Size:* ${paperSize}%0A` +
        `*Quantity:* ${quantity}%0A` +
        `*Notes:* ${notes || 'None'}`;
    
    // Replace with your WhatsApp business number
    const whatsappNumber = '919876543210';
    const whatsappURL = `https://wa.me/${whatsappNumber}?text=${message}`;
    
    window.open(whatsappURL, '_blank');
}

// ===== Preloader (Optional) =====
window.addEventListener('load', () => {
    const preloader = document.querySelector('.preloader');
    if (preloader) {
        preloader.classList.add('fade-out');
        setTimeout(() => {
            preloader.style.display = 'none';
        }, 500);
    }
});

// ===== Service Worker Registration (for PWA - Optional) =====
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('SW registered'))
        //     .catch(error => console.log('SW registration failed'));
    });
}
